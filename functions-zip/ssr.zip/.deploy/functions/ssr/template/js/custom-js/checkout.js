// Add your custom JavaScript for checkout here.
// window.pmarket = [];
// window.pmarket.consultaPonto = function(cpf){
//     axios.post('https://us-central1-pontomarket-ecomplus.cloudfunctions.net/app/get/points', {
//         storeId : storefront.settings.store_id,
//         cpf: '43335443608'      
//     })
//     .then(function(response){
//         console.log(response)
        
//     })    
// }

// window.pmarket.consultaPonto(41681618893);